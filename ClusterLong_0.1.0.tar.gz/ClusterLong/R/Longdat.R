#' One example longitudinal data
#'
#' There are four clusters exists, with size 5,65,65,65. For details, please refer to the original paper.
#'
#' @format 200 hundred subjects with number of observations within [4,12]. The total number of observation is 1606.
#' It is a list of two elements: Dat is a list of id, observation times, and 5 outcomes; Label is the right label.

"Longdat"
